import 'package:flutter/material.dart';
import '../widgets/circle_indicator.dart';

class MainPage extends StatelessWidget {
  const MainPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const SizedBox(height: 10),

            const Text(
              "Live-\nTraining",
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 34,
                fontWeight: FontWeight.w600,
                color: Colors.white,
              ),
            ),

            const SizedBox(height: 10),

            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _tab("Schritt", false),
                const SizedBox(width: 12),
                _tab("Trab", true),
                const SizedBox(width: 12),
                _tab("Galopp", false),
              ],
            ),

            const SizedBox(height: 20),

            SizedBox(
              width: 280,
              height: 300,
              child: Column(
                children: [
                  GestureDetector(
                    onTap: () => Navigator.pushNamed(context, "/takt"),
                    child: const CircularIndicator(
                      label: "Takt",
                      value: 0.75,
                      color: Color(0xFF3AE6A1),
                    ),
                  ),
                  const SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      GestureDetector(
                        onTap: () => Navigator.pushNamed(context, "/symmetrie"),
                        child: const CircularIndicator(
                          label: "Geraderichtung",
                          value: 0.62,
                          color: Color(0xFFE6B63A),
                        ),
                      ),
                      GestureDetector(
                        onTap: () => Navigator.pushNamed(context, "/last"),
                        child: const CircularIndicator(
                          label: "Lastaufnahme",
                          value: 0.44,
                          color: Color(0xFFE63A4A),
                        ),
                      ),
                    ],
                  )
                ],
              ),
            ),

            Column(
              children: [
                Container(
                  width: 300,
                  height: 56,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    gradient: const LinearGradient(
                      colors: [
                        Color(0xFF7FDB70),
                        Color(0xFF6DBF63),
                      ],
                    ),
                  ),
                  child: const Center(
                    child: Text(
                      "Start Training",
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w600,
                        color: Colors.black,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 18),
                Container(
                  width: 300,
                  height: 56,
                  decoration: BoxDecoration(
                    color: const Color(0xFF2A2F2C),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Center(
                    child: Text(
                      "Export Daten",
                      style: TextStyle(
                        fontSize: 18,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _tab(String label, bool active) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        color: active ? Colors.white : const Color(0xFF1C2622),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: active ? Colors.black : Colors.white,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }
}
